﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Payment_wcf.DatabaseManager
{
    internal interface ISQL : IDML, IDQL
    {
    }
}
