﻿using System.Runtime.Serialization;

namespace Payment_wcf
{
    [DataContract]
    public class Customer
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public int Age { get; set; }

        [DataMember]
        public string City {get; set;}

    }
}